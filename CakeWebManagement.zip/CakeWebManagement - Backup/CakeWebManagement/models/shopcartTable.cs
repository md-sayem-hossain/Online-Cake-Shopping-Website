﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CakeWebManagement.models
{
    public class shopcartTable
    {
        public int id { get; set; }
        public int idP { get; set; }
        public int priceP { get; set; }
        public int qtyP { get; set; }
    }
}